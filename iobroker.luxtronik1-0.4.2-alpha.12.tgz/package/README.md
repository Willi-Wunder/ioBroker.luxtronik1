![Logo](admin/luxtronik1.png)

# ioBroker.luxtronik1

![Number of Installations](http://iobroker.live/badges/luxtronik1-installed.svg) ![Number of Installations](http://iobroker.live/badges/luxtronik1-stable.svg) [![NPM version](http://img.shields.io/npm/v/iobroker.luxtronik1.svg)](https://www.npmjs.com/package/iobroker.luxtronik1)
[![Downloads](https://img.shields.io/npm/dm/iobroker.luxtronik1.svg)](https://www.npmjs.com/package/iobroker.luxtronik1)

[![NPM](https://nodei.co/npm/iobroker.luxtronik1.png?downloads=true)](https://nodei.co/npm/iobroker.luxtronik1/)

An ioBroker adapter for Luxtronik 1 - heatpump - controllers (i.e. Alpha Innotec, Siemens...)

Install adapter, create instance.
Install hardware: i.e. RS232 to LAN adapter to the serial interface (RS232) of the heatpumps mainbord.
Specs: serial cabe: link PINS 2, 3 and 5  (if it does not work, change pins 2 and 3)
RS232 to LAN converter: i.e. USR TCP232 – 302.
Settings serial interface : 57600/8/N/1 , Mode :TCP-Server
Reset Timeout:0

Set luxtronik - IP-adress, port and polling - intervall

Tested on luxtronik 1 and AlphaInnotec heatpump

Reads different values and stats of your heatpump (temperatures, errors, running time,...).
Controls Luxtronik 1 by setting values in the 'control' - channel. Controls the following values:

-   Hotwater - temperature setting
-   Heating - mode
-   Hot water - mode
-   Heating - curve (difference, endpoint, startingpoint, nightly reduction).
-   Hysteresis hot water
-   Hysteresis heating

Values in the 'control' - channel have to be set with ack=false to trigger an action.

## Changelog
<!--
    Placeholder for the next version (at the beginning of the line):
    ### **WORK IN PROGRESS**
-->
### **WORK IN PROGRESS**
- Stability: every request now has a timeout, so a silent RS232-LAN converter can no longer block the adapter
- Stability: poll requests run strictly one after another (no more overlapping connections to the converter)
- Stability: connection problems no longer restart the whole instance; the connection is reset and retried with the next poll
- `info.connection` is true only after a complete data set was received
- Timers are cleared on unload; invalid port is reported instead of crashing
- Fixed copy-paste bugs (wrong error counter for data set 3200, log texts for hysteresis)
- Control commands wait up to ~2 min for a running poll cycle instead of resetting the connection after 10 s (which aborted the cycle)
- Log 'ack is not set!' (was shown for every control command) is now a debug message; timeout warning shows the number of received characters
- No misleading warnings ('unvollständiger Datensatz ...') when the adapter is stopped during a request
- Node.js: minimum version is now 20 (`engines`); CI tests Node.js 20, 22 and 24; `@types/node` 22; ESLint `ecmaVersion` 2022
- Fixed typo `adapterl` (8 places): reading a missing state (e.g. `ablaufzeiten.WPseit`) threw a ReferenceError inside a callback and could crash the adapter
- A request that times out now aborts the rest of the poll cycle (next try with the next poll) instead of waiting up to 15 s for each remaining request; the warning tells whether the converter could not be reached or was connected but the Luxtronik did not answer
- Fixed: several waiting commands (or a poll tick) increased a shared counter and reset the connection, which killed a command that was still being sent (could leave the controller with an incomplete command, log: 'Befehlsverarbeitung unvollständig'). A waiting command/poll now only resets the lock if no socket is open for 30 s
- Fixed: changing heating curve values (AbwRLs, Endpunkt, ParaV, NachtAbs) or hysteresis (HystBWs, HystHKs) sent an incomplete data set (`3401;;20`) to the controller, which answered with error 779 ('Befehlsverarbeitung unvollständig'). The adapter now reads the current values first and writes them back with the changed value; if the read fails nothing is written and a warning is logged
- Fixed: these commands (read - write - read) and the follow-up reads after changing the hot water target / switching times used fixed timers and could open a second connection while another one was still active. They now run strictly one after the other as one unit
- Set values (hot water target, heating curve, hysteresis) must be numbers; anything else is rejected with a warning instead of being sent to the controller. Decimal values are rounded to tenths of a degree
- The hot water target command is repeated at most 3 times if the controller reports a different value (was: endless repetition)
- Hysteresis set values follow the limits of the controller: hot water 1 to 30 in whole degrees (0.5 steps are rejected), heating 0.5 to 3 in 0.5 steps; values outside are rejected with a warning and not sent. Object `control.HystBWs`: step 1
- Hot water target (`control.BWs`) accepts whole degrees 30 to 65 only (0.5 steps are rejected). At start the adapter updates range, step, unit and name of `control.BWs`, `control.HystBWs` and `control.HystHKs` in existing installations
- Pause of 2 s between two requests to the controller (as in the original; can be changed with the hidden setting `requestGap` in ms). Poll requests and the steps of multi-step commands respect it
- The timeout warning names the request that did not get an answer (e.g. 'Abfrage 2100')
- Every data set written to the controller is logged at info level ('Schreibe an Luxtronik: ...') so that unexpected changes can be traced
- Added resilience tests with a mock converter (`test/testConnectionResilience.js`)

### 0.4.1 (2024-04-18)
- (mcm1957) Workflow has been fixed

### 0.4.0 (2024-04-18)
- (mcm1957) Adapter requires node.js >= 18 and js-controller >= 5 now
- (mcm1957) Dependencies have been updated

### 0.3.6

-   testing and dependencies updated

### 0.3.5

-   set ready for js-controller 4.0

### 0.3.4

-   control timer hot water added

### 0.3.3

-   data exchange optimized

### 0.3.2

-   bugfix

### 0.3.1

-   bugfixes related to js-controller update (3.3x)

### 0.3.0

-   info on temperature - settings and hysteresis - control added

### 0.2.7

-   status-info added.

### 0.2.6

-   input-data and timers (Eingänge & Ablaufzeiten) added.

### 0.2.5

-   outlet-data added by @pingus01.

### 0.2.4

-   comm-errors fixed, 'control'-values are updated now.

### 0.2.3

-   adapter - restart in case of connection - problems added.

### 0.2.2

-   .npmignore and .gitignore added, small bugfix.

### 0.2.1

-   Readme / License update.

### 0.2.0

-   missing temperature values added, displays now all available temperature values.

### 0.1.0

-   error-handling on communication errors optimized, adapter restart in case of multiple communication errors.

### 0.0.7

-   error-handling on connections added.

### 0.0.6

-   diminished risk of multiple connection, small bugfixes

### 0.0.5

-   controls hotwater-temperature, heating- & hotwater - mode and heating-curve setting.

### 0.0.4

-   error - handling optimized

### 0.0.3

-   Reads mode heating, water and heating-curve

### 0.0.2

-   First published version

### 0.0.1

-   In development stage

## License

The MIT License (MIT)

Copyright (c) 2024 iobroker-community-adapters <iobroker-community-adapters@gmx.de>
Copyright (c) 2018-2023 forelleblau marceladam@gmx.ch

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
